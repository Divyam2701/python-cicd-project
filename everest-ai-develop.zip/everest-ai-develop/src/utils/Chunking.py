from langchain_text_splitters import RecursiveCharacterTextSplitter
from config import settings
from src.utils.Logger import log_message

class Chunking:
    def chunk_text(self, text: str, chunk_size: int, chunk_overlap: int) -> list[str]:
        try:
            log_message("info", "Starting chunking process.")
            if not text:
                log_message("warning", "Empty text input received for chunking.")
                return []

            splitter = RecursiveCharacterTextSplitter(
                chunk_size=chunk_size,
                chunk_overlap=chunk_overlap,
                length_function=len,
                is_separator_regex=False,
            )

            documents = splitter.create_documents([text])
            chunks = [doc.page_content for doc in documents]

            log_message("info", f"Successfully chunked text into {len(chunks)} chunks.")
            return chunks

        except Exception as e:
            log_message("error", f"Error during chunking: {e}")
            return []