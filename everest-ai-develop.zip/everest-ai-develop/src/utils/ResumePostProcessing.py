import json
import re

def process_resume_recommendations(llm_response_text: str) -> dict:
    """
    Parses the LLM's resume recommendation output into a valid JSON object.

    This function first attempts to parse the input string as a clean JSON.
    If that fails, it uses a robust regex-based fallback mechanism to extract
    each recommendation object and its key-value pairs, then reconstructs the
    final JSON structure as specified in the prompt.

    Args:
        llm_response_text: The raw string output from the LLM.

    Returns:
        A dictionary in the format {"recommendations": [...]}, which will be
        empty if no valid data could be extracted.
    """
    # --- Step 1: Attempt to parse as valid JSON ---
    try:
        # Pre-clean the text from common LLM artifacts like markdown code blocks
        match = re.search(r"\{.*\}", llm_response_text, re.DOTALL)
        if match:
            clean_text = match.group(0)
            return json.loads(clean_text)
        else:
            # If no JSON-like structure is found at all, go to fallback
            raise json.JSONDecodeError("No JSON object found", llm_response_text, 0)
            
    except json.JSONDecodeError:
        print("INFO: Direct JSON parsing failed. Falling back to regex extraction.")
        
        # --- Step 2: Fallback to Regex Extraction ---
        recommendations_list = []
        
        # This regex finds text blocks that start with `{` and end with `}`.
        # It's non-greedy (.*?) and handles multi-line content (re.DOTALL).
        # This is robust to surrounding text like "Here are the results...".
        recommendation_blocks = re.findall(r'\{(.*?)\}', llm_response_text, re.DOTALL)

        for block in recommendation_blocks:
            data = {}
            
            # Regex for `resume_id`: Captures a string value.
            # `([^"]+)` captures one or more characters that are not a double quote.
            id_match = re.search(r'"resume_id":\s*"([^"]+)"', block)
            if id_match:
                data['resume_id'] = id_match.group(1)

            # Regex for `employee-name`: Captures a string value.
            name_match = re.search(r'"employee-name":\s*"([^"]+)"', block)
            if name_match:
                data['employee_name'] = name_match.group(1)

            # Regex for `matching-score`: Captures a number.
            # `(\d+)` captures one or more digits.
            score_match = re.search(r'"matching-score":\s*(\d+)', block)
            if score_match:
                data['matching_score'] = int(score_match.group(1))

            # Regex for `match-reason`: Captures a string value that can span newlines.
            # We use `([\s\S]*?)` inside the quotes to capture everything, including newlines.
            reason_match = re.search(r'"match-reason":\s*"([\s\S]*?)"', block, re.DOTALL)
            if reason_match:
                # Clean up any potential escaping the LLM might have added
                reason_text = reason_match.group(1).replace('\\n', '\n').replace('\\"', '"').strip()
                data['match_reason'] = reason_text
            
            # A recommendation is only valid if it has at least a name or ID.
            if 'resume_id' in data or 'employee-name' in data:
                recommendations_list.append(data)
                
        # --- Step 3: Build the final valid JSON structure ---
        return {"recommendations": recommendations_list}