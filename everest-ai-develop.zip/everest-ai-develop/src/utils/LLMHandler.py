import logging
from config import settings
from langchain_community.llms import cohere
from langchain_community.embeddings import CohereEmbeddings
from langchain.chat_models.openai import ChatOpenAI
from langchain.embeddings.openai import OpenAIEmbeddings

logger = logging.getLogger("ProjectLogger")

class LLMHandler:
    def __init__(self):
        self.api_key = settings.LLM_API_KEY
        self.model = settings.LLM_MODEL
        self.model_embedding = settings.LLM_EMBEDDING_MODEL
        self.provider = settings.LLM_PROVIDER.lower()

        self.llm = None
        self.embedder = None
        
        try:
            self.llm = self.load_llm()
            logger.info(f"Loaded LLM for provider: {self.provider}")
        except Exception as e:
            logger.error(f"Failed to load LLM: {e}")
            raise

        try:
            self.embedder = self.load_embedder()
            logger.info(f"Loaded embedder for provider: {self.provider}")
        except Exception as e:
            logger.error(f"Failed to load embedder: {e}")
            raise

    def load_llm(self):
        """Load the LLM based on the provider configuration."""
        try:
            if self.provider == "openai":
                llm = ChatOpenAI(model_name=self.model, openai_api_key=self.api_key)
            elif self.provider == "cohere":
                llm = cohere(model=self.model, cohere_api_key=self.api_key)
            else:
                raise ValueError(f"Unsupported LLM provider: {self.provider}")
            return llm
        except Exception as e:
            logger.error(f"Error loading LLM from provider {self.provider}: {e}")
            raise RuntimeError(f"Error loading LLM from provider {self.provider}: {e}")

    def load_embedder(self):
        """Load the embedding model based on the provider configuration."""
        try:
            if self.provider == "openai":
                embedder = OpenAIEmbeddings(model=self.model_embedding, openai_api_key=self.api_key)
            elif self.provider == "cohere":
                embedder = CohereEmbeddings(model=self.model_embedding, cohere_api_key=self.api_key)
            else:
                raise ValueError(f"Unsupported embedding provider: {self.provider}")
            return embedder
        except Exception as e:
            logger.error(f"Error loading embedder from provider {self.provider}: {e}")
            raise RuntimeError(f"Error loading embedder from provider {self.provider}: {e}")