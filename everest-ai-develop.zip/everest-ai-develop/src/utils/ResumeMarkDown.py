import re
from typing import Dict, Any, List

class JsonToMarkdown:
    @staticmethod
    def clean_html(text):
        if not text:
            return ""
        return re.sub('<[^<]+?>', '', str(text)).replace('\n', ' ').replace('\r', '')

    @staticmethod
    def generate_markdown(resume: Dict[str, Any]) -> str:
        layout = resume['resume_layout']
        markdown = []

        for section in layout:
            item = section['item']
            section_title = item.get('custom_section_name')

            if section_title == "Personal Information":
                if item.get("name"):
                    markdown.append(f"# {item['name']}")
                if item.get("headline"):
                    markdown.append(f"**{item['headline']}**")
                if item.get("location"):
                    markdown.append(f"-  {item['location']}")
                if item.get("email"):
                    markdown.append(f"-  {item['email']}")
                if item.get("phone_number"):
                    markdown.append(f"-  {item['phone_number']}")
                if item.get("website"):
                    markdown.append(f"- {item['website']}")
                markdown.append("")

            elif 'summary' in item:
                markdown.append("## Summary")
                markdown.append(JsonToMarkdown.clean_html(item['summary']))
                markdown.append("")

            elif section_title == "Skills":
                markdown.append("## Skills")
                for skill in item.get('skills', []):
                    sk = skill['rb_skills_data_id']
                    markdown.append(f"- **{sk['name']}** ({sk['level']}%): {JsonToMarkdown.clean_html(sk['description'])}")
                markdown.append("")

            elif section_title == "Work Experience":
                markdown.append("## Work Experience")
                for exp in item.get('work_experiences', []):
                    w = exp['rb_work_experiences_data_id']
                    markdown.append(f"### {w['designation']} at {w['company_name']}")
                    markdown.append(f"*{w['start_date']} - {w['end_date']}*")
                    if w.get("description"):
                        markdown.append(JsonToMarkdown.clean_html(w['description']))
                    markdown.append("")

            elif section_title == "Education":
                markdown.append("## Education")
                for edu in item.get('educations', []):
                    e = edu['rb_educations_data_id']
                    markdown.append(f"- **{e['degree']}**, {e['institution']} (*{e['start_date']} – {e['end_date']}*)")
                markdown.append("")

            elif section_title == "Portfolio":
                markdown.append("## Projects")
                for proj in item.get('portfolios', []):
                    p = proj['rb_portfolios_data_id']
                    markdown.append(f"### {p['project_title']}")
                    markdown.append(f"**Role**: {p['role']}")
                    markdown.append(f"**Technologies**: {p['technologies']}")
                    markdown.append(f"**Description**: {JsonToMarkdown.clean_html(p['description'])}")
                    markdown.append(f"**Contribution**:\n{JsonToMarkdown.clean_html(p['contribution'])}")
                    markdown.append("")

            elif section_title == "Availability":
                markdown.append("## Availability")
                markdown.append("Available upon request.")
                markdown.append("")

        return '\n'.join(markdown)

    @staticmethod
    def generate_markdown_for_all(data: List[Dict[str, Any]]) -> str:
        return "\n\n---\n\n".join([JsonToMarkdown.generate_markdown(resume) for resume in data])

