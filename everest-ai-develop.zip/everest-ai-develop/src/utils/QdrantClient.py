import uuid
import traceback
from datetime import datetime

from qdrant_client import QdrantClient as QClient, models
from qdrant_client.http.models import Filter, FieldCondition, MatchValue, FilterSelector

from openai import OpenAI
from openai import AuthenticationError, APIConnectionError

from config import settings
from src.utils.Logger import log_message


class ResumeQdrantClient:
    def __init__(self, url: str, api_key: str, collection_name: str):
        try:
            self.client = QClient(url=url, api_key=api_key)
            self.collection_name = collection_name  
            self._ensure_collection()
            log_message("info", f"Qdrant client initialized for collection: {self.collection_name}")
        except Exception as e:
            log_message("error", f"Failed to initialize Qdrant client: {e}\n{traceback.format_exc()}")
            raise

    def _ensure_collection(self):
        existing = {c.name for c in self.client.get_collections().collections}
        if self.collection_name not in existing:
            self.client.create_collection(
                collection_name=self.collection_name,
                vectors_config=models.VectorParams(size=1536, distance=models.Distance.COSINE),
            )
            log_message("info", f"Created collection: {self.collection_name}")
        else:
            log_message("info", f"Collection already exists: {self.collection_name}")

    def _generate_resume_point_id(self, resume_id, chunk_index):
        raw_id = f"{resume_id}_{chunk_index}"
        try:
            point_id = str(uuid.uuid5(uuid.NAMESPACE_DNS, raw_id))
            log_message("debug", f"Generated point ID: {point_id} for raw_id: {raw_id}")
            return point_id
        except Exception as e:
            log_message("error", f"UUID generation failed for raw_id {raw_id}: {e}\n{traceback.format_exc()}")
            raise

    def _ensure_resume_id_index(self):
        try:
            self.client.create_payload_index(
                collection_name=self.collection_name,
                field_name="resume_id",
                field_schema=models.PayloadSchemaType.KEYWORD,
            )
            log_message("info", "Payload index on 'resume_id' ensured.")
        except Exception as e:
            if "already exists" not in str(e):
                log_message("error", f"Failed to ensure payload index on 'resume_id': {e}")

    def Resume_store(self, resume_id, chunks, vectors, created_at: datetime, resume_json=None):
        log_message("info", f"Storing {len(chunks)} chunks to Qdrant for resume_id: {resume_id}")

        employee_name = ""
        if resume_json:
            try:
                for section in resume_json.get("resume_layout", []):
                    item = section.get("item", {})
                    if item.get("custom_section_name") == "Personal Information":
                        employee_name = item.get("name", "")
                        break
            except Exception as e:
                log_message("warning", f"Could not extract employee_name: {e}")

        if not chunks or not vectors or len(chunks) != len(vectors):
            log_message("error", f"Invalid input: chunks={len(chunks) if chunks else 0}, vectors={len(vectors) if vectors else 0}")
            return False

        try:
            if len(vectors[0]) == 0:
                log_message("error", "Vector size is zero.")
                return False
        except Exception as e:
            log_message("error", f"Error checking vector size: {e}\n{traceback.format_exc()}")
            return False

        points = []
        for idx, (chunk, vector) in enumerate(zip(chunks, vectors)):
            try:
                point_id = self._generate_resume_point_id(resume_id, idx)
                points.append(
                    models.PointStruct(
                        id=point_id,
                        vector=vector,
                        payload={
                            "resume_id": str(resume_id),
                            "employee_name": employee_name,
                            "chunk": chunk,
                            "created_at": created_at.isoformat()
                        }
                    )
                )
            except Exception as e:
                log_message("error", f"Failed to create point for chunk index {idx}: {e}\n{traceback.format_exc()}")
                return False

        try:
            self.client.upsert(
                collection_name=self.collection_name,
                points=points
            )
            log_message("info", f"{len(points)} points upserted successfully for resume_id: {resume_id}")
            return True
        except Exception as e:
            log_message("error", f"Failed to upsert points: {e}\n{traceback.format_exc()}")
            return False

    def Resume_delete(self, resume_id: str) -> bool:
        self._ensure_resume_id_index()
        try:
            self.client.delete(
                collection_name=self.collection_name,
                points_selector=FilterSelector(
                    filter=Filter(
                        must=[FieldCondition(key="resume_id", match=MatchValue(value=resume_id))]
                    )
                )
            )
            log_message("info", f"Successfully deleted data for resume_id: {resume_id}")
            return True
        except Exception as e:
            log_message("error", f"Error deleting resume {resume_id}: {e}\n{traceback.format_exc()}")
            return False

    @staticmethod
    def check_qdrant_health():
        try:
            qdrant_client = QClient(
                url=settings.RESUME_QDRANT_URL,
                api_key=settings.RESUME_QDRANT_API_KEY
            )
            qdrant_client.get_collections()
            return True, "available"
        except Exception as e:
            print(f"Qdrant health check failed: {e}")
            return False, f"unavailable - {type(e).__name__}"

    @staticmethod
    def check_openai_health():
        if not settings.LLM_API_KEY:
            return False, "unavailable - OPENAI_API_KEY not set"
        try:
            openai_client = OpenAI(api_key=settings.LLM_API_KEY)
            openai_client.models.list()
            return True, "available"
        except AuthenticationError:
            return False, "unavailable - AuthenticationError"
        except APIConnectionError:
            return False, "unavailable - APIConnectionError"
        except Exception as e:
            print(f"OpenAI health check failed: {e}")
            return False, f"unavailable - {type(e).__name__}"
