from openai import OpenAI
from typing import List
from config import settings
from src.utils.Logger import log_message
class Embedder:
    def __init__(self, model_name=settings.LLM_EMBEDDING_MODEL):
        try:
            self.client = OpenAI(api_key=settings.LLM_API_KEY)
            self.model_name = model_name
        except Exception as e:
            raise RuntimeError(f"Error initializing OpenAI client: {e}")

    def embed(self, chunks: List[str]) -> List[List[float]]:       
        if not chunks:            
            return []
        try:
            log_message("info", "Generating embeddings for document chunks.")
            response = self.client.embeddings.create(
                model=self.model_name,
                input=chunks
            )
            return [d.embedding for d in response.data]
        except Exception as e:
            log_message("error", f"Error occurred while generating embeddings: {str(e)}")
            raise RuntimeError(f"Error embedding with OpenAI: {e}")