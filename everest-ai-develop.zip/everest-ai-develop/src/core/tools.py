# tool file (Corrected)
import logging
import json
from typing import List, Tuple, Union, Dict, Any
from qdrant_client import QdrantClient
from qdrant_client.models import ScoredPoint
from langchain_community.embeddings import OpenAIEmbeddings
from langchain_core.tools import Tool
from config import settings

class QdrantSearchTool:
    def __init__(self, qdrant: QdrantClient, collection_name: str, openai_api_key: str):
        self.qdrant = qdrant
        self.collection_name = collection_name
        self.embeddings = OpenAIEmbeddings(openai_api_key=openai_api_key)

    def run(self, query: str) -> Tuple[str, List[ScoredPoint]]:
        if not query:
            logging.warning("Empty query received.")
            return "Invalid query.", []

        logging.info(f"Running QdrantSearchTool with query: {query}")
        try:
            query_vector = self.embeddings.embed_query(query)
            hits = self.qdrant.search(
                collection_name=self.collection_name,
                query_vector=query_vector,
                with_payload=True,
                with_vectors=False,
                limit=5,
                score_threshold=0.7 # Optional: Add a threshold to improve result quality
            )
            # --- NEW: Store the score in the payload for later use ---
            for hit in hits:
                hit.payload['score'] = hit.score

            # Create a simple string summary for the LLM to see
            summary = "\n".join([f"Found resume for: {h.payload.get('employee_name', 'Unknown')}" for h in hits])
            return summary, hits

        except Exception as e:
            logging.error(f"Qdrant search failed: {e}", exc_info=True)
            return f"Qdrant search failed: {str(e)}", []

    def as_tool(self) -> Tool:
        # --- CHANGED: Reworked the tool function for robustness ---
        def tool_func(input_data: Union[str, Dict[str, Any]]) -> str:
            """
            Robust function to handle both str and dict inputs from the LLM.
            The output of this function MUST be a JSON serializable string.
            """
            if isinstance(input_data, dict):
                query = input_data.get("query")
            else:
                query = input_data

            if not isinstance(query, str):
                error_msg = json.dumps({"error": "Query must be a string."})
                logging.error(error_msg)
                return error_msg

            results_str, hits = self.run(query)

            # The ToolNode expects a string output, so we serialize our dict to a JSON string.
            # This structured output will be parsed by our router.
            output_dict = {
                "results_summary": results_str,
                "hits": [hit.payload for hit in hits] # Extract payloads for final formatting
            }
            return json.dumps(output_dict)

        return Tool.from_function(
            func=tool_func,
            name="resume_search_qdrant",
            description=(
                "Searches for relevant resumes in the Qdrant database based on a query. "
                "The input can be a simple string query. "
                "The output is a JSON string containing a summary and a list of candidate hits."
            )
        )

# Instantiate Tool
qdrant_client = QdrantClient(
    url=settings.RESUME_QDRANT_URL,
    api_key=settings.RESUME_QDRANT_API_KEY
)

search_tool = QdrantSearchTool(
    qdrant=qdrant_client,
    collection_name=settings.RESUME_QDRANT_COLLECTION_NAME,
    openai_api_key=settings.LLM_API_KEY
)

TOOLS = [search_tool.as_tool()]