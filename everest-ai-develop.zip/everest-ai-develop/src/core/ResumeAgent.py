# core/graph.py

import logging
import json
from datetime import UTC, datetime
from typing import Dict, List, Literal, cast
from dataclasses import replace

from langgraph.graph import StateGraph, END
from langchain_core.messages import SystemMessage, HumanMessage, AIMessage
from langchain_openai import ChatOpenAI
from langgraph.prebuilt import ToolNode

from config import settings
from src.core.state import State, InputState
from src.core.tools import TOOLS  # Import TOOLS as well

from src.core.prompts.Resume_Prompt import (
    SYSTEM_PROMPT_Resume_Matcher,
    PLANNER_PROMPT_Resume_Matcher,
)

logger = logging.getLogger(__name__)


# -------------------------------------- Update State Helper --------------------------------------
def update_state(state: State, key: str, value) -> State:
    return replace(state, **{key: value})


# -------------------------------------- Planner Node ---------------------------------------------
async def planner(state: State) -> State:
    planner_llm = ChatOpenAI(
        model_name=settings.LLM_MODEL,
        openai_api_key=settings.LLM_API_KEY
    )

    messages = [
        SystemMessage(content=SYSTEM_PROMPT_Resume_Matcher),
        HumanMessage(content=f"{PLANNER_PROMPT_Resume_Matcher}\nQuery: {state.query}")
    ]    
    plan = await planner_llm.ainvoke(messages)
    return update_state(state, "plan", plan.content)


# -------------------------------------- Model Node -----------------------------------------------
async def call_model(state: State) -> State:
    model = ChatOpenAI(
        model_name=settings.LLM_MODEL,
        openai_api_key=settings.LLM_API_KEY
    ).bind_tools(TOOLS)

    system_message = SYSTEM_PROMPT_Resume_Matcher.format(
        system_time=datetime.now(tz=UTC).isoformat()
    )

    response = cast(
        AIMessage,
        await model.ainvoke(
            [{"role": "system", "content": system_message}, *state.messages]
        ),
    )

    

    result = []
    if state.is_last_step and not response.tool_calls:
        try:
            result_json = json.loads(response.content)
            result = result_json.get("recommendations", [])
        except Exception as e:
            logger.warning(f"Failed to parse final output JSON: {e}")

    return replace(state, messages=state.messages + [response], result=result)


# -------------------------------------- Router Function -------------------------------------------
def route_model_output(state: State) -> Literal["__end__", "tools"]:
    last_message = state.messages[-1]
    if not isinstance(last_message, AIMessage):
        raise ValueError(f"Expected AIMessage, got {type(last_message).__name__}")

    return "tools" if last_message.tool_calls else "__end__"


# -------------------------------------- Graph Builder ---------------------------------------------
builder = StateGraph(State, input=InputState)

# builder.add_node("planner", planner)

builder.add_node("call_model", call_model)
builder.add_node("tools", ToolNode(TOOLS))

builder.set_entry_point("call_model")
# builder.add_edge("planner", "call_model")
builder.add_conditional_edges("call_model", route_model_output)
builder.add_edge("tools", "call_model")

graph = builder.compile(name="Resume Agent")

# -------------------------------------- Final Graph -----------------------------------------------
# graph = build_graph()
