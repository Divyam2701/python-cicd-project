from datetime import datetime
from src.utils.ResumeMarkDown import JsonToMarkdown
from src.utils.QdrantClient import ResumeQdrantClient
from src.utils.Logger import log_message
from src.utils.Chunking import Chunking
from src.utils.Embedding import Embedder
from config import settings

class ResumePipeline:
    def __init__(self, resume_json: dict, resume_id: str):
        self.resume_json = resume_json
        self.resume_id = resume_id
        self.chunker = Chunking()
        self.embedder = Embedder()
        self.qdrant_client = ResumeQdrantClient(
            url=settings.RESUME_QDRANT_URL,
            api_key=settings.RESUME_QDRANT_API_KEY,
            collection_name=settings.RESUME_QDRANT_COLLECTION_NAME
        )

    async def process_resume(self) -> str:
        log_message("info", f"Starting resume processing pipeline for resume_id: {self.resume_id}")
        markdown = JsonToMarkdown.generate_markdown(self.resume_json)
        chunks = self.chunker.chunk_text(markdown, settings.RESUME_CHUNK_SIZE, settings.RESUME_CHUNK_OVERLAP)
        vectors = self.embedder.embed(chunks)
        created_at = datetime.utcnow()
        success = self.qdrant_client.Resume_store(self.resume_id, chunks, vectors, created_at, resume_json=self.resume_json)
        if success:
            log_message("info", f"Resume {self.resume_id} processed and stored successfully.")
        else:
            log_message("error", f"Failed to store resume {self.resume_id} in Qdrant.")
        return self.resume_id
