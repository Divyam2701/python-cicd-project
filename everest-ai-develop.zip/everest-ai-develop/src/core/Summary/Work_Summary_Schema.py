from pydantic import BaseModel, Field

class WorkSummaryInput(BaseModel):
    position_name: str = Field(..., description="Name of the position.")
    short_summary: str = Field(..., min_length=10, description="Original work summary.")

class WorkSummaryOutput(BaseModel):
    rewritten_summary: str = Field(..., description="The rewritten, improved work summary.")
    