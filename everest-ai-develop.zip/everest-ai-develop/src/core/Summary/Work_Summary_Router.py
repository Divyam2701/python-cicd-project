from fastapi import APIRouter, HTTPException
from src.core.Summary.Work_Summary_Schema import WorkSummaryInput, WorkSummaryOutput
from src.core.Summary.Work_Summary_Core import WorkSummaryRewriter

router = APIRouter()
rewriter = WorkSummaryRewriter()

@router.post("/Rewrite_Summary", response_model=WorkSummaryOutput)
async def rewrite_summary(payload: WorkSummaryInput):
    try:
        result = await rewriter.rewrite(payload.position_name, payload.short_summary)
        return WorkSummaryOutput(rewritten_summary=result)
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))
