# app/core/worksummary.py
from langchain_openai import ChatOpenAI
from langchain_core.prompts import ChatPromptTemplate
from langchain_core.output_parsers import StrOutputParser
from src.core.Summary.Summary_Prompt import REWRITE_SUMMARY_PROMPT_TEMPLATE
from config import settings
import re

class WorkSummaryRewriter:
    def __init__(self):
        self.llm = ChatOpenAI(
            model=settings.LLM_MODEL,
            openai_api_key=settings.LLM_API_KEY,
            temperature=0.7
        )
        self.prompt = ChatPromptTemplate.from_template(REWRITE_SUMMARY_PROMPT_TEMPLATE)
        self.output_parser = StrOutputParser()
        self.chain = self.prompt | self.llm | self.output_parser

    async def rewrite(self, position_name: str, short_summary: str) -> str:
        input_data = {
            "position_name": position_name,
            "short_summary": short_summary,
        }
        rewritten_text = await self.chain.ainvoke(input_data)
        processed = rewritten_text.strip()
        
        processed = re.sub(r'(?i)^.*?(rewritten summary:|summary:)\s*', '', processed).strip()
        
        return processed
