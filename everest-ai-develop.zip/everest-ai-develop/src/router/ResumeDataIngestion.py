from fastapi import APIRouter, HTTPException
from typing import List
from src.core.ResumeDataIngestion import ResumePipeline
from src.schema.ResumeSchema import ResumeDataIngestionInputSchema
from src.utils.Logger import log_message

from pydantic import BaseModel


router = APIRouter()

@router.post("/Resume_Ingestion/")
async def ingest_resume_json(resumes: ResumeDataIngestionInputSchema):
    results = []
    errors = []
    for resume in resumes.data:  # <-- FIXED: use resumes.data
        try:
            resume_json = resume.dict()
            pipeline = ResumePipeline(resume_json=resume_json, resume_id=resume.id)
            processed_id = await pipeline.process_resume()
            results.append({"id": processed_id, "status": "processed"})
        except Exception as e:
            log_message("error", f"Error processing resume {resume.id}: {str(e)}")
            errors.append({"id": resume.id, "error": str(e)})
    if errors:
        return {"processed": results, "errors": errors}
    return results