from fastapi import APIRouter, HTTPException, status
from src.utils.QdrantClient import ResumeQdrantClient
from config import settings

router = APIRouter()
qdrant_client = ResumeQdrantClient(
    url=settings.RESUME_QDRANT_URL,
    api_key=settings.RESUME_QDRANT_API_KEY,
    collection_name=settings.RESUME_QDRANT_COLLECTION_NAME
)

@router.delete("/Resume_Delete", status_code=status.HTTP_200_OK)
async def delete_resume(resume_id: str):
    """
    Delete all Qdrant points for a given resume_id.
    """
    success = qdrant_client.Resume_delete(resume_id) 
    if success:
        return {"message": f"Resume with id {resume_id} deleted successfully."}
    raise HTTPException(
        status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
        detail=f"Failed to delete resume with id {resume_id}."
    )
