import logging
from fastapi import APIRouter, HTTPException
from src.core.ResumeAgent import graph
from src.schema.ResumeSchema import QueryRequest, QueryResponse, ResumeMatch
from src.utils.ResumePostProcessing import process_resume_recommendations

ResumeAgent = APIRouter()

logger = logging.getLogger(__name__)

@ResumeAgent.post("/Resume_Agent")
async def search(query_request: QueryRequest):
    try:
        response = await graph.ainvoke({"messages": query_request.query})
        print("--- Before Post Processing---")
        logger.info(f"Response from graph: {response["messages"][-1].content}")
        print(f"Response from graph: {response["messages"][-1].content}")
        print("---After Post Processing---")
        response = process_resume_recommendations(response["messages"][-1].content)
        return response
        # return response["messages"][-1].content

    except Exception as e:
        logger.error(f"Error in /search endpoint: {e}")
        raise HTTPException(status_code=500, detail="Internal server error")