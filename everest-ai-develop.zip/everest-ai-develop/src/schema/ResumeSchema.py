from pydantic import BaseModel, EmailStr
from datetime import datetime
from typing import List, Optional, Union

# === Data Models ===

class SkillData(BaseModel):
    name: Optional[str] = None
    level: Optional[int] = None
    description: Optional[str] = None

class SkillItem(BaseModel):
    rb_skills_data_id: Optional[SkillData] = None

class WorkExperienceData(BaseModel):
    company_name: Optional[str] = None
    designation: Optional[str] = None
    start_date: Optional[str] = None
    end_date: Optional[str] = None
    description: Optional[str] = None

class WorkExperienceItem(BaseModel):
    rb_work_experiences_data_id: Optional[WorkExperienceData] = None

class EducationData(BaseModel):
    institution: Optional[str] = None
    degree: Optional[str] = None
    start_date: Optional[str] = None
    end_date: Optional[str] = None

class EducationItem(BaseModel):
    rb_educations_data_id: Optional[EducationData] = None

class PortfolioData(BaseModel):
    project_title: Optional[str] = None
    role: Optional[str] = None
    technologies: Optional[str] = None
    contribution: Optional[str] = None
    description: Optional[str] = None

class PortfolioItem(BaseModel):
    rb_portfolios_data_id: Optional[PortfolioData] = None

# === Section Models ===

class PersonalInfo(BaseModel):
    avatar: Optional[str] = None
    custom_section_name: Optional[str] = None
    date_created: Optional[datetime] = None
    date_updated: Optional[datetime] = None
    email: Optional[EmailStr] = None
    headline: Optional[str] = None
    id: Optional[str] = None
    location: Optional[str] = None
    name: Optional[str] = None
    phone_number: Optional[str] = None
    user_created: Optional[str] = None
    user_updated: Optional[str] = None
    website: Optional[str] = None

class Summary(BaseModel):
    custom_section_name: Optional[str] = None
    date_created: Optional[datetime] = None
    date_updated: Optional[datetime] = None
    id: Optional[str] = None
    summary: Optional[str] = None
    user_created: Optional[str] = None
    user_updated: Optional[str] = None

class SkillsSection(BaseModel):
    custom_section_name: Optional[str] = None
    date_created: Optional[datetime] = None
    date_updated: Optional[datetime] = None
    id: Optional[str] = None
    sort: Optional[str] = None
    user_created: Optional[str] = None
    user_updated: Optional[str] = None
    skills: Optional[List[SkillItem]] = None

class WorkExperienceSection(BaseModel):
    custom_section_name: Optional[str] = None
    date_created: Optional[datetime] = None
    date_updated: Optional[datetime] = None
    id: Optional[str] = None
    sort: Optional[str] = None
    user_created: Optional[str] = None
    user_updated: Optional[str] = None
    work_experiences: Optional[List[WorkExperienceItem]] = None

class EducationSection(BaseModel):
    custom_section_name: Optional[str] = None
    date_created: Optional[datetime] = None
    date_updated: Optional[datetime] = None
    id: Optional[str] = None
    sort: Optional[str] = None
    user_created: Optional[str] = None
    user_updated: Optional[str] = None
    educations: Optional[List[EducationItem]] = None

class PortfolioSection(BaseModel):
    custom_section_name: Optional[str] = None
    date_created: Optional[datetime] = None
    date_updated: Optional[datetime] = None
    id: Optional[str] = None
    sort: Optional[str] = None
    user_created: Optional[str] = None
    user_updated: Optional[str] = None
    portfolios: Optional[List[PortfolioItem]] = None

class AvailabilitySection(BaseModel):
    availability_time: Optional[str] = None
    custom_section_name: Optional[str] = None
    date_created: Optional[datetime] = None
    date_updated: Optional[datetime] = None
    id: Optional[str] = None
    user_created: Optional[str] = None
    user_updated: Optional[str] = None

# === Wrapper Models ===

class ResumeItem(BaseModel):
    item: Optional[
        Union[
            PersonalInfo,
            Summary,
            SkillsSection,
            WorkExperienceSection,
            EducationSection,
            PortfolioSection,
            AvailabilitySection
        ]
    ] = None

class ResumeSchema(BaseModel):
    id: Optional[str] = None
    resume_layout: List[ResumeItem]

class ResumeDataIngestionInputSchema(BaseModel):
    data: List[ResumeSchema]

class ResumeMatch(BaseModel):
    resume_id: str
    employee_name: str
    score: float
    reason: str

class QueryRequest(BaseModel):
    query: str

class QueryResponse(BaseModel):
    matches: List[ResumeMatch]
    

