from fastapi import FastAPI
from src.router.ResumeDataIngestion import router as ResumeDataIngestion
from src.router.ResumeAgent import ResumeAgent
from src.router.ResumeDataDelete import router as ResumeDataDelete
from fastapi.middleware.cors import CORSMiddleware
from src.core.Summary.Work_Summary_Router import router as work_summary_router
from src.utils.QdrantClient import ResumeQdrantClient
from fastapi.responses import JSONResponse
from fastapi import status

app = FastAPI()

# Add CORS middleware (optional, but recommended for frontend/backend separation)
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],  # Or specify your frontend domain(s)
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

@app.get("/")
def read_root():
    return {"message": "Search Functionality"}

@app.get("/Health", tags=["Health"])
def health_check():
    """
    Performs a health check on the service and its dependencies.
    Returns 200 OK if all systems are operational.
    Returns 503 Service Unavailable if any critical dependency is down.
    """
    # Perform checks for all dependencies
    qdrant_ok, qdrant_status_msg = ResumeQdrantClient.check_qdrant_health()
    openai_ok, openai_status_msg = ResumeQdrantClient.check_openai_health()

    # Determine overall health status
    is_healthy = qdrant_ok and openai_ok

    # Prepare the detailed response body
    response_body = {
        "status": "healthy" if is_healthy else "unhealthy",
        "dependencies": {
            "qdrant": {
                "status": qdrant_status_msg,
                "healthy": qdrant_ok
            },
            "openai_llm": {
                "status": openai_status_msg,
                "healthy": openai_ok
            }
        }
    }

    # Determine the appropriate HTTP status code
    http_status_code = status.HTTP_200_OK if is_healthy else status.HTTP_503_SERVICE_UNAVAILABLE

    return JSONResponse(content=response_body, status_code=http_status_code)


# Resume Work Summary Router
app.include_router(work_summary_router,tags=["Resume Work Summary"])

#Resume Data Ingestion and Deletion
app.include_router(ResumeDataIngestion, tags=["Resume Data Ingestion"])
app.include_router(ResumeDataDelete, tags=["Resume Data Ingestion"])

#Agent
#app.include_router(LangchainAgentSearch, tags=["Langchain Agent Search"])
app.include_router(ResumeAgent, tags=["Resume Agent"])