from pydantic_settings import BaseSettings
import os
from dotenv import load_dotenv

load_dotenv()
class Settings(BaseSettings):
    RESUME_QDRANT_URL: str
    RESUME_QDRANT_API_KEY: str
    RESUME_CHUNK_SIZE: int
    RESUME_CHUNK_OVERLAP: int
    RESUME_QDRANT_COLLECTION_NAME: str
    
    LLM_API_KEY: str
    LLM_MODEL: str
    LLM_PROVIDER: str
    LLM_EMBEDDING_MODEL: str
    DEBUG: str
    
    
 

    class Config:
        env_file = ".env"
        extra="allow"

settings = Settings()

